export interface PersonalDetail {
  id: string;
  label: string;
  value: string;
}

export interface WorkExperience {
  id: string;
  jobTitle: string;
  company: string;
  dateRange: string;
  tasks: string[];
}

export interface CvData {
  name: string;
  profilePictureUrl: string;
  dob: string;
  personalDetails: PersonalDetail[];
  skillsSummary: string;
  workExperience: WorkExperience[];
}
