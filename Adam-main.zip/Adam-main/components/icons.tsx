import React from 'react';

export const CoveboLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 200 40" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path fill="currentColor" d="M22.5,0.5 C10.4,0.5 0.5,10.4 0.5,22.5 L0.5,22.5 L0.5,29.5 L22.5,29.5 C26.4,29.5 29.5,26.4 29.5,22.5 L29.5,22.5 C29.5,10.4 19.6,0.5 7.5,0.5 L22.5,0.5 Z M22.5,10.5 C15.9,10.5 10.5,15.9 10.5,22.5 C10.5,22.5 10.5,22.5 10.5,22.5 L22.5,22.5 L22.5,10.5 Z" />
    <text x="45" y="29" fontFamily="Poppins, sans-serif" fontSize="30" fontWeight="bold" fill="#333">COVEBO</text>
  </svg>
);

export const ConveyorIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M10.25 2.75a2.5 2.5 0 0 0-4.5 0" />
    <path d="M7.5 2.75v12.5" />
    <path d="m18 15.25-2.5-2.5" />
    <path d="m15.5 15.25 2.5-2.5" />
    <path d="m13 15.25-2.5-2.5" />
    <path d="m10.5 15.25 2.5-2.5" />
    <path d="M12.25 21.25h-9a1 1 0 0 1-1-1v-4.5a1 1 0 0 1 1-1h13.5a1 1 0 0 1 1 1v4.5a1 1 0 0 1-1 1h-2.25" />
    <circle cx="18" cy="18" r="3.25" />
  </svg>
);

export const ScannerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
   <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M5.5 4.75a1 1 0 0 1 1-1h11a1 1 0 0 1 1 1v14.5a1 1 0 0 1-1 1h-11a1 1 0 0 1-1-1Z" />
    <path d="M8.5 8.75h7" />
    <path d="M8.5 12.75h4" />
    <path d="M21.25 10.75a4.5 4.5 0 0 0 0 3" />
  </svg>
);
