import React from 'react';
import { CvData } from '../types';
import { CoveboLogo, ConveyorIcon, ScannerIcon } from './icons';

interface CvPreviewProps {
  cvData: CvData;
  id: string;
}

const CvPreview: React.FC<CvPreviewProps> = ({ cvData, id }) => {
  const { name, profilePictureUrl, dob, personalDetails, skillsSummary, workExperience } = cvData;

  const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <h2 className="text-[#CE0031] text-lg tracking-[0.3em] font-semibold mb-6">
      {children}
    </h2>
  );

  return (
    <div id={id} className="bg-white text-black shadow-2xl" style={{ width: '210mm', minHeight: '297mm', fontFamily: "'Poppins', sans-serif" }}>
      <header className="bg-[#CE0031] rounded-br-[60px] p-8 pl-10 flex text-white relative h-[200px]">
        <div className="w-1/3 pt-1">
          <CoveboLogo className="h-8 w-auto fill-current" />
        </div>
        <div className="w-2/3 flex justify-between items-center pl-12">
          <h1 className="text-5xl font-bold leading-tight tracking-wide break-words">{name}</h1>
          <div className="flex flex-col gap-3">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center border-2 border-white/50 shrink-0">
               <ConveyorIcon className="w-8 h-8"/>
            </div>
             <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center border-2 border-white/50 shrink-0">
                <ScannerIcon className="w-8 h-8"/>
             </div>
          </div>
        </div>
        <div className="absolute top-[80px] left-10 w-[180px] h-[180px] rounded-full bg-white p-2 shadow-lg">
          <img
            src={profilePictureUrl || 'https://via.placeholder.com/180'}
            alt={name}
            className="w-full h-full rounded-full object-cover"
          />
        </div>
      </header>

      <main className="flex pt-24">
        <div className="w-[38%] pl-10 pr-6 pb-8">
          <div className="border border-[#CE0031] p-6 min-h-[400px]">
              <p className="text-xl tracking-[0.2em] font-light mb-8">{dob}</p>
              <SectionTitle>PERSONAL DESCRIPTION</SectionTitle>
              
              {personalDetails.map(detail => (
                <div key={detail.id} className="mb-4 break-words">
                  <h3 className="text-[#CE0031] text-sm tracking-[0.2em] font-semibold uppercase">{detail.label}</h3>
                  <p className="font-medium text-sm">{detail.value}</p>
                </div>
              ))}
          </div>
           {skillsSummary && (
             <div className="mt-8">
                 <p className="font-semibold tracking-wider text-sm text-center">{skillsSummary}</p>
             </div>
          )}
        </div>

        <div className="w-[62%] pr-10">
          <SectionTitle>WORK EXPERIENCE</SectionTitle>
          {workExperience.map((exp) => (
            <div key={exp.id} className="mb-4 pb-4 border-b border-gray-200 last:border-b-0">
              <p className="font-bold text-sm tracking-wide break-words">{exp.jobTitle}, {exp.company}</p>
              <p className="text-xs text-gray-600 mb-2">{exp.dateRange}</p>
              <ul className="list-disc pl-5 text-xs space-y-1">
                {exp.tasks.map((task, i) => (
                  <li key={i} className="break-words">{task}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default CvPreview;