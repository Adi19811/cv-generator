import React, { useState } from 'react';
import { CvData, PersonalDetail, WorkExperience } from '../types';
import { parseCvImage } from '../services/geminiService';

const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = error => reject(error);
});

interface CvFormProps {
  cvData: CvData;
  setCvData: React.Dispatch<React.SetStateAction<CvData>>;
}

const CvForm: React.FC<CvFormProps> = ({ cvData, setCvData }) => {
    const [isParsing, setIsParsing] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setIsParsing(true);
        setError(null);
        try {
            const base64Image = await toBase64(file);
            const parsedData = await parseCvImage(base64Image, file.type);
            setCvData(prev => ({ ...prev, ...parsedData }));
        } catch (err) {
            console.error(err);
            setError('Nie udało się przeanalizować obrazu. Spróbuj ponownie.');
        } finally {
            setIsParsing(false);
        }
        e.target.value = ''; // Reset file input
    };

    const handleFieldChange = (field: keyof CvData, value: string) => {
        setCvData(prev => ({ ...prev, [field]: value }));
    };

    // FIX: The original `handleDynamicChange` had a generic type `T` that was incorrectly inferred, causing type errors.
    // This new implementation uses generics that correctly infer the types based on the `section` argument,
    // ensuring type safety for `field` and `value`. It also uses an immutable update pattern, which is a React best practice.
    const handleDynamicChange = <
        K extends 'personalDetails' | 'workExperience',
        F extends keyof CvData[K][number]
    >(
        section: K,
        index: number,
        field: F,
        value: CvData[K][number][F]
    ) => {
        const newItems = cvData[section].map((item, i) =>
            i === index ? { ...item, [field]: value } : item
        );
        setCvData(prev => ({ ...prev, [section]: newItems }));
    };

    const addItem = (section: 'personalDetails' | 'workExperience') => {
        const id = crypto.randomUUID();
        let newItem;
        switch (section) {
            case 'personalDetails':
                newItem = { id, label: '', value: '' };
                break;
            case 'workExperience':
                newItem = { id, jobTitle: '', company: '', dateRange: '', tasks: [] };
                break;
        }
        setCvData(prev => ({ ...prev, [section]: [...(prev[section] as any[]), newItem] }));
    };

    const removeItem = (section: 'personalDetails' | 'workExperience', id: string) => {
        setCvData(prev => ({ ...prev, [section]: (prev[section] as any[]).filter(item => item.id !== id) }));
    };

    const Input = ({ label, value, onChange }) => (
        <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">{label}</label>
            <input type="text" value={value} onChange={onChange} className="w-full border border-gray-300 rounded-md p-2 text-sm focus:ring-red-500 focus:border-red-500" />
        </div>
    );
    
    const Section: React.FC<{title: string; children: React.ReactNode}> = ({title, children}) => (
        <div className="mb-6 p-4 border border-gray-200 rounded-lg bg-gray-50/50">
            <h3 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2">{title}</h3>
            {children}
        </div>
    );
    
    return (
        <div className="space-y-6">
            <Section title="Wypełnij z AI">
                 <p className="text-sm text-gray-600 mb-2">Wgraj obraz swojego obecnego CV, a my postaramy się uzupełnić dane za Ciebie.</p>
                <input type="file" accept="image/*" onChange={handleImageUpload} disabled={isParsing} className="text-sm file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-red-50 file:text-red-700 hover:file:bg-red-100" />
                {isParsing && <p className="text-sm text-blue-600 mt-2">Analizowanie obrazu...</p>}
                {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
            </Section>

            <Section title="Podstawowe informacje">
                <Input label="Imię i nazwisko" value={cvData.name} onChange={e => handleFieldChange('name', e.target.value)} />
                <Input label="URL zdjęcia profilowego" value={cvData.profilePictureUrl} onChange={e => handleFieldChange('profilePictureUrl', e.target.value)} />
                <Input label="Data urodzenia" value={cvData.dob} onChange={e => handleFieldChange('dob', e.target.value)} />
            </Section>

            <Section title="Dane Osobowe">
                 <div className="grid grid-cols-12 gap-2 mb-2 text-sm font-bold">
                    <div className="col-span-5">Etykieta</div>
                    <div className="col-span-6">Wartość</div>
                </div>
                {cvData.personalDetails.map((detail, index) => (
                    <div key={detail.id} className="grid grid-cols-12 gap-2 items-center mb-2">
                        <input type="text" aria-label="Etykieta" placeholder="Np. Prawo jazdy" value={detail.label} onChange={e => handleDynamicChange('personalDetails', index, 'label', e.target.value)} className="col-span-5 border border-gray-300 rounded-md p-2 text-sm" />
                        <input type="text" aria-label="Wartość" placeholder="Np. Kat. B" value={detail.value} onChange={e => handleDynamicChange('personalDetails', index, 'value', e.target.value)} className="col-span-6 border border-gray-300 rounded-md p-2 text-sm" />
                        <button onClick={() => removeItem('personalDetails', detail.id)} className="text-red-500 hover:text-red-700 col-span-1 text-2xl font-light">&times;</button>
                    </div>
                ))}
                <button onClick={() => addItem('personalDetails')} className="mt-2 text-sm text-red-600 font-semibold">+ Dodaj szczegół</button>
            </Section>
            
            <Section title="Umiejętności (dolna lewa sekcja)">
                 <textarea placeholder="Wpisz kluczowe umiejętności" rows={4} value={cvData.skillsSummary} onChange={e => handleFieldChange('skillsSummary', e.target.value)} className="w-full border border-gray-300 rounded-md p-2 text-sm" />
            </Section>

            <Section title="Doświadczenie zawodowe">
                {cvData.workExperience.map((exp, index) => (
                    <div key={exp.id} className="p-3 border rounded-md mb-3 bg-white relative">
                         <button onClick={() => removeItem('workExperience', exp.id)} className="absolute top-1 right-2 text-red-500 hover:text-red-700 text-2xl font-light">&times;</button>
                        <input placeholder="Stanowisko" value={exp.jobTitle} onChange={e => handleDynamicChange('workExperience', index, 'jobTitle', e.target.value)} className="w-full border-b p-1 mb-2 text-sm" />
                        <input placeholder="Firma" value={exp.company} onChange={e => handleDynamicChange('workExperience', index, 'company', e.target.value)} className="w-full border-b p-1 mb-2 text-sm" />
                        <input placeholder="Okres (np. 01.2022 - Obecnie)" value={exp.dateRange} onChange={e => handleDynamicChange('workExperience', index, 'dateRange', e.target.value)} className="w-full border-b p-1 mb-2 text-sm" />
                        <textarea placeholder="Zadania (każde w nowej linii)" value={exp.tasks.join('\n')} onChange={e => handleDynamicChange('workExperience', index, 'tasks', e.target.value.split('\n'))} rows={4} className="w-full border-b p-1 text-sm" />
                    </div>
                ))}
                 <button onClick={() => addItem('workExperience')} className="mt-2 text-sm text-red-600 font-semibold">+ Dodaj doświadczenie</button>
            </Section>
        </div>
    );
};

export default CvForm;