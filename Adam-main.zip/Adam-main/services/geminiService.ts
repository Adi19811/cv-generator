import { GoogleGenAI, Type } from "@google/genai";
import { CvData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING, description: "Full name of the candidate." },
    dob: { type: Type.STRING, description: "Date of birth, e.g., DD/MM/YYYY." },
    personalDetails: {
      type: Type.ARRAY,
      description: "List of personal details like certifications, driving status, etc.",
      items: {
        type: Type.OBJECT,
        properties: {
          label: { type: Type.STRING, description: "The title of the detail, e.g., 'ENGLISH LEVEL'." },
          value: { type: Type.STRING, description: "The value of the detail, e.g., 'communicative'." },
        },
        required: ['label', 'value'],
      },
    },
    skillsSummary: { type: Type.STRING, description: "A summary of key skills, often listed under a separate heading, e.g. HEFTRUCK, PACKAGES, LOADING/UNLOADING." },
    workExperience: {
      type: Type.ARRAY,
      description: "List of previous jobs.",
      items: {
        type: Type.OBJECT,
        properties: {
          jobTitle: { type: Type.STRING, description: "The job title." },
          company: { type: Type.STRING, description: "The company name." },
          dateRange: { type: Type.STRING, description: "The start and end dates of employment." },
          tasks: {
            type: Type.ARRAY,
            description: "A list of responsibilities and achievements.",
            items: { type: Type.STRING },
          },
        },
        required: ['jobTitle', 'company', 'dateRange', 'tasks'],
      },
    },
  },
};

export const parseCvImage = async (base64ImageData: string, mimeType: string): Promise<Partial<CvData>> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64ImageData,
              mimeType: mimeType,
            },
          },
          {
            text: 'Extract the information from this CV image. Populate all fields according to the provided JSON schema. For personal details, use the original labels from the document. For work experience tasks, list each responsibility or achievement as a separate string in the array. Ignore any education or courses sections.',
          },
        ],
      },
      config: {
        responseMimeType: 'application/json',
        responseSchema: responseSchema,
      },
    });

    const jsonText = response.text.trim();
    if (!jsonText) {
        throw new Error("Gemini returned an empty response.");
    }
    const parsedData = JSON.parse(jsonText);

    // Add unique IDs to array items for React keys
    ['personalDetails', 'workExperience'].forEach(key => {
        if (parsedData[key] && Array.isArray(parsedData[key])) {
            parsedData[key].forEach((item: any) => item.id = crypto.randomUUID());
        }
    });

    return parsedData;

  } catch (error) {
    console.error("Error parsing CV image with Gemini:", error);
    throw new Error("Failed to parse CV image.");
  }
};