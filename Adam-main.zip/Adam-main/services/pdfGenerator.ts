
// This assumes jsPDF and html2canvas are loaded from a CDN and available on the window object.
declare const jspdf: any;
declare const html2canvas: any;

export const generatePdf = async (elementId: string): Promise<void> => {
  const originalElement = document.getElementById(elementId);
  if (!originalElement) {
    throw new Error(`Element with id "${elementId}" not found.`);
  }

  // Create a clone of the element to render it off-screen without transforms
  const clone = originalElement.cloneNode(true) as HTMLElement;
  
  // Style the clone to be rendered off-screen but with its true dimensions
  clone.style.position = 'absolute';
  clone.style.top = '0';
  clone.style.left = '-9999px';
  clone.style.width = '210mm';
  clone.style.height = '297mm';
  clone.style.transform = 'none'; // Crucially, remove any scaling

  document.body.appendChild(clone);

  try {
    const canvas = await html2canvas(clone, {
      scale: 3, // Higher scale for better quality
      useCORS: true,
      logging: false,
      width: clone.offsetWidth,
      height: clone.offsetHeight,
      windowWidth: clone.scrollWidth,
      windowHeight: clone.scrollHeight,
    });
    
    const imgData = canvas.toDataURL('image/png');
    
    // Use window.jspdf.jsPDF for CDN version
    const { jsPDF } = jspdf;
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const a4Width = 210;
    const a4Height = 297;
    pdf.addImage(imgData, 'PNG', 0, 0, a4Width, a4Height);
    pdf.save('cv.pdf');
  } catch (error) {
    console.error("PDF generation failed", error);
    // Re-throw the error if you want the caller to handle it
    throw error;
  } finally {
    // Clean up by removing the clone from the DOM
    document.body.removeChild(clone);
  }
};
